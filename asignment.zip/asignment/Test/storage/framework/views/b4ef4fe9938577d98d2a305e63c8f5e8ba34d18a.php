<!-- create.blade.php -->



<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    <h1 align="center">About Us</h1>
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form action="<?php echo e(url('contactus')); ?>" class="form-image-upload" method="POST">
          <div class="form-group">
              <?php echo csrf_field(); ?>
              <table align="center">
              <tr>
              <td><label>Name</label></td>
              <td><input type="text" name="name" id="name" placeholder="Enter Name"></td>
              </tr>
              <tr>
              <td><label>Email</label></td>
              <td><input type="text" name="email" id="email" placeholder="Enter Email"></td>
              </tr>
              <tr>
              <td><label>Subject</label></td>
              <td><input type="text" name="sub" id="sub" placeholder="Enter Subject"></td>
              </tr>
              <tr>
              <td><label>Message</label></td>
              <td><textarea rows="3" cols="20" name="message" id="message" placeholder="Enter Message"></textarea></td>
              </tr>
              <tr>
              <td><button>Save</button></td>
              <td align="right"><button>Clear</button></td>


              </tr>

              </table>


           </div>



      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Untitled Folder 3/Aptha/resources/views/contactus.blade.php ENDPATH**/ ?>