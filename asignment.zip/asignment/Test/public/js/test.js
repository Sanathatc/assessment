alertify.logPosition("bottom right")
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
new Vue({
    el: '#vue',
        data: {
            itemRec: [],
            item: {},
            editMode:false,
            editObject: null,
            total:0,
            client_name: null,
            adress: null,
            customerList: [],
            customer_id:null
        },
        watch: {
            item: {
                handler() {
                    if(this.item.hasOwnProperty('c')) {
                        var items = [{ id: 2, column_name: 'item2' }, {id: 1, column_name: 'item1'}]
                        this.item.c_text = items.filter(item => item.id == this.item.c)[0].column_name
                    }
                },
                deep: true
            }
        },
        methods: {
            addProduct()
            {
                 this.itemRec.push({ id: Math.random(300,9999), item_name:this.item.item_name,
                    quantity:this.item.quantity, uom:this.item.uom, rate:this.item.rate },
                )

                $.ajax({
                    url:  'createSalesorder',
                    type: 'POST',
                    data: { item_name:this.item.item_name,quantity:this.item.quantity, uom:this.item.uom, rate:this.item.rate},
                    dataType: 'json',
                }).done(response => {
                    alertify.success('Invoice added sucessfull');
                    this.fetchSalesOrder()
                })
                 this.item = {}

            },
            editProduct(subjects){
                this.item = JSON.parse(JSON.stringify(subjects))
                this.editMode = true
             //   this.totalCalc()
            },
            updatePg() {
                this.itemRec.forEach((item, index) => {
                    if(item.id == this.item.id) {
                        Vue.set(this.itemRec, index, JSON.parse(JSON.stringify(this.item)))
                        this.item = {}
                    }
                })
                this.editMode = false
            },
            cancelEditPg() {
                this.editMode = false
                this.editObject = null
                this.item = {}
            },

            deletepg(index) {
               this.itemRec.splice(index,1)
               this.totalCalc()
            },
            addCustomer() {
                $.ajax({
                    url:  'addcustomer',
                    type: 'POST',
                    data: { client_name: this.client_name, adress:this.adress},
                    dataType: 'json',
                }).done(response => {
                    alertify.success('Customer added sucessfull');
                    this.fetchCustomer()
                })
            },
            fetchCustomer() {
                $.ajax({
                    url:  'fetchCustomer',
                    type: 'POST',
                    data: { },
                    dataType: 'json',
                }).done(response => {
                    this.customerList = response

                })
            },
            fetchSalesOrder() {
                 $.ajax({
                    url:  'fetchSalesorder',
                    type: 'POST',
                    data: { },
                    dataType: 'json',
                }).done(response => {
                    this.itemRec = response
                })
            }

        },
        created() {
            this.fetchCustomer()
            this.fetchSalesOrder()
        }
    })
