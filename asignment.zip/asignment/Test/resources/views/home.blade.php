

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Hello Bulma!</title>
{{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
<script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script> --}}
<script defer src="js/bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="js/bootstrap/css/bootstrap.css">
</head>
<body>

<section class="section">
  <header style="background: #0b0f90;
    height: 3em;"> </header>
 <div style="display:inline-block; float: right; margin-top: 6px;width: 6em;" >
    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>
       <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
          @csrf
      </form>
</div>
<div class="container" id="vue">
<div class="field">
  <div class="col-md-10" style="margin-left: -16px;">
    <select class="form-control" style="margin-top: 17px;">
        <option v-for="customer in customerList" :value="customer.id">@{{ customer.name }}</option>
    </select>
  </div>
  <div class="col-md-2">
    <button class="btn btn-success pull-right" style="margin-top: 17px;margin-left: 2px;margin-right: 11px;margin-bottom: 10px;" data-target="#exampleGrid" data-toggle="modal" type="button"> Add Customer </button>
  </div>
</div>
<div class="modal fade" id="exampleGrid" aria-hidden="true" aria-labelledby="exampleGrid" role="dialog" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                    </button>
                                    <h4 class="modal-title">Move Conversion Factor</h4>
                                </div>
                                <div class="modal-body" style="font-size: 0.9em; padding-top: 0;">
                                    <div class="example-grid">
                                        <div class="row" >
                                            <div class="col-xs-6 col-lg-6">
                                                <div class="example-col">Client Name</div>
                                            </div>
                                            <div class="col-xs-6 col-lg-6">
                                                <input type="text" class="form-control" v-model="client_name">
                                            </div>
                                            <div class="col-xs-6 col-lg-6">
                                                <div class="example-col">Location</div>
                                            </div>
                                            <div class="col-xs-6 col-lg-6">
                                                <textarea class="form-control" v-model="adress"></textarea>
                                            </div>

                                        </div>


                                    </div>
                                </div>
                                <div class="modal-footer">
                                      <button type="button" class="btn btn-default btn-pure" data-dismiss="modal" id="copyModelcancel">Close</button>
                                      <button type="button" class="btn btn-primary" @click="addCustomer">Save</button>
                                    </div>
                            </div>
                        </div>
                    </div>

<table class="table">
  <tr><td>Item Name</td>
      <td>Quantity</td>
      <td>Units</td>
      <td>Amount</td>
      <td>Total</td>
      <td> Action </td></tr>
    <tr>
      <td>
          <select v-model="item.item_name" class="form-control" style="width: 22em;">
            <option>Item1</option>
            <option>Item2</option>
      </td>
      <td>
          <input class="form-control" type="number" placeholder="Text input" v-model="item.quantity"></td>
      <td>
          <select  v-model="item.uom" class="form-control"><option value="1">KG</option><option value="2">Units</option></select>
       </td>
      <td>
          <input class="form-control" type="text" placeholder="Text input" v-model="item.rate">
      </td>
      <td> = @{{ Number(item.quantity) + Number(item.rate) }}</td>
      <td v-if="!editMode">
        <a class="button is-rounded" @click="addProduct">Add</a>
      </td>
      <td v-else>
        <a class="button is-rounded" @click="updatePg">update</a>
        <a class="button is-rounded" @click="cancelEditPg">cancel</a>
      </td>
  </tr>
</table>
<table class="table table-bordered" v-if="(itemRec).length>0"><tr><td>Item Name</td>
  <td>Quantity</td><td>UOM</td>
  <td>Amount</td><td>Action</td></tr>
<template v-for="(item, index) in itemRec">
<tr><td>@{{item.item_name}}</td>
  <td>@{{item.quantity}}</td>
  <td>@{{item.uom}}</td>
  <td>@{{item.rate}}</td>
  <td>

<button class="btn btn-sm btn-danger" @click="deletepg(index)">Delete<i aria-hidden="true" class="fa fa-trash-o"></i></button>
<button class="btn btn-sm btn-primary" @click="editProduct(item)">Edit<i aria-hidden="true" class="fa fa-edit"></i></button>
  </td></tr>
</template>
</table>
</div>
</section>
</body>
</html>
<script type="text/javascript" src="{{ URL::asset('js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('js/jquery.js')}}"></script>

<script type="text/javascript" src="{{ URL::asset('js/vue.dev.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('js/vuetify/vuetify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('js/alertify.js/alertify.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('js/vue-components/checkbox-multiselect.js')}}"></script>
<script type="text/javascript" src="{{ URL::asset('js/test.js')}}"></script>
