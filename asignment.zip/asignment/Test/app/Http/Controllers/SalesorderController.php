<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;
use App\Salesorder;

class SalesorderController extends Controller
{
    public function createSalesOrder(Request $request)
    {
       return Salesorder::create([
                'item_code' => '01',
                'item_name' => $request->item_name,
                'customer_id' => $request->customer_id,
                'item' => '01',
                'rate' =>  $request->rate,
                'quantity' =>  $request->quantity,
                ]);

    }
    public function fetchSalesOredr(Request $request)
    {
        return Salesorder::get();
    }
    
}
