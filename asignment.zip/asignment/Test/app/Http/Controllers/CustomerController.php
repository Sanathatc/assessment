<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;

class CustomerController extends Controller
{
    public function addCustomer(Request $request)
    {
        return Client::create([
                'name' => $request->client_name,
                'location' => $request->adress,
                ]);
    }
    public function fetchCustomer(Request $request)
    {
        return Client::get();
    }
    
}
